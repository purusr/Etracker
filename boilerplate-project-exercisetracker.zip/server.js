const express = require('express')
const app = express()
const cors = require('cors')
const mongoose = require('mongoose')
const mongodb = require('mongodb')
const bodyparser = require('body-parser')
require('dotenv').config()
mongoose.connect(process.env.MONGO_URI,{useNewUrlParser: true, useUnifiedTopology: true})
const { Schema } = mongoose;

 let personSchema = new Schema({
     username: String
    });
  const Person = mongoose.model("Terson", personSchema);

let exerciseSchema = new Schema({
  _id:String,
  description:{ type: String, required: [true, "description required"] },
  duration:{type: String, required:[true, "duration required"]},
  date: Date
});

const Exercise = mongoose.model("Exercise", exerciseSchema);

app.use(bodyparser.urlencoded({extended:true}))
app.use(bodyparser.json())
app.use(cors())
app.use(express.static('public'))


 

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/index.html')
});



app.post('/api/users', (req,res)=>{
  console.log(req.body.username);
  const newPerson = new Person(
   {username:req.body.username});
   console.log(username);
   newPerson.save((err, data)=>{
     if(err){
      res.send("Username taken");
    }else{
    console.log(data);
   res.json({"username":data.username, "_id":data.id});
    }
  });
});

app.post('/api/users/:_id/exercises', (req,res)=>{
  const{_id, description,duration,date}=req.body;

  console.log(_id);
  Person.findById(_id,(err,data)=>{
  if(err){
    res.send("Incorrect user ID");
  }
  else {
    console.log(data.username);
    const uname= data.username;
    const exercise1= new Exercise({_id,description,duration,date});
    res.json({uname,_id,description,duration,date});
  }
  });
  });
  

app.get('/api/users/:_id/logs',(req,res)=>{
const{_id,from,to,limit}=req.params;
console.log(_id);
Person.findById(_id, (err,data)=>{
if(!data){
  res.send("Unknown userId")
}else{
  const username = data.username;
  console.log(username);
  console.log({"from": from, "to": to, "limit":limit});
  Exercise.find({_id},{date:{$gte:new Date(from), $lte:new Date(to)}}).select(['_id','description','duration','date']).limit(+limit).exec((err,data)=>{
    let customdata= data.map(exer =>{
   let dateFormated= new Date(exer.date).toDateString();
    return {id: exer.id, description:exer.description, duration:exer.duration, date: dateFormatted}
  })
  if(!data){
    res.json({
      "_id": _id,
      "username":username,
      "count":0,
      "log":[] 
    })
  }
else{
  res.json({
    "_id": _id,
    "username":username,
    "count": data.length,
    "log":customdata
  })
}

  });
}
});
});






const listener = app.listen(process.env.PORT || 3000, () => {
  console.log('Your app is listening on port ' + listener.address().port)
})


